import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  CheckCircle2,
  Circle,
} from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { LoadingState, ErrorState, EmptyState } from "@/components/States";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getProjectsSummary } from "@/api/projects";
import { formatMYR } from "@/lib/format";
import type { ProjectSummary } from "@/types";

export const Route = createFileRoute("/")({
  component: DashboardPage,
});

function StatCell({
  label,
  value,
  icon: Icon,
  tone = "default",
}: {
  label: string;
  value: number;
  icon: React.ElementType;
  tone?: "default" | "positive" | "negative" | "warning" | "success";
}) {
  const toneClass =
    tone === "positive" || tone === "success"
      ? "text-success"
      : tone === "negative"
        ? "text-destructive"
        : tone === "warning"
          ? "text-warning"
          : "text-foreground";
  return (
    <div className="rounded-md border bg-muted/30 p-3">
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Icon className="h-3.5 w-3.5" />
        {label}
      </div>
      <div className={`mt-1 text-base font-semibold ${toneClass}`}>
        {formatMYR(value)}
      </div>
    </div>
  );
}

function DashboardPage() {
  const [data, setData] = useState<ProjectSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await getProjectsSummary());
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load summary");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const totals = data.reduce(
    (acc, p) => {
      acc.income += p.total_income;
      acc.expenses += p.total_expenses;
      acc.net += p.net_position;
      acc.claimed += p.total_claimed;
      acc.unclaimed += p.total_unclaimed;
      return acc;
    },
    { income: 0, expenses: 0, net: 0, claimed: 0, unclaimed: 0 },
  );

  return (
    <div>
      <PageHeader
        title="Dashboard"
        description="Financial summary across all projects (MYR)."
      />

      {/* Totals */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5 mb-6">
        <StatCell label="Total Income" value={totals.income} icon={TrendingUp} tone="success" />
        <StatCell label="Total Expenses" value={totals.expenses} icon={TrendingDown} tone="negative" />
        <StatCell
          label="Net Position"
          value={totals.net}
          icon={Wallet}
          tone={totals.net >= 0 ? "success" : "negative"}
        />
        <StatCell label="Claimed" value={totals.claimed} icon={CheckCircle2} tone="default" />
        <StatCell label="Unclaimed" value={totals.unclaimed} icon={Circle} tone="warning" />
      </div>

      {loading && <LoadingState />}
      {error && <ErrorState message={error} onRetry={load} />}
      {!loading && !error && data.length === 0 && (
        <EmptyState
          title="No projects yet"
          description="Create a project to start tracking expenses and income."
        />
      )}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {data.map((p) => (
          <Card key={p.project_id} className="hover:shadow-sm transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-2">
                <CardTitle className="text-base">
                  <Link
                    to="/projects"
                    className="hover:underline"
                  >
                    {p.project_name}
                  </Link>
                </CardTitle>
                <Badge
                  variant={p.net_position >= 0 ? "default" : "destructive"}
                  className={p.net_position >= 0 ? "bg-success text-success-foreground hover:bg-success/90" : ""}
                >
                  Net {formatMYR(p.net_position)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2">
                <StatCell label="Income" value={p.total_income} icon={TrendingUp} tone="success" />
                <StatCell label="Expenses" value={p.total_expenses} icon={TrendingDown} tone="negative" />
                <StatCell label="Claimed" value={p.total_claimed} icon={CheckCircle2} />
                <StatCell label="Unclaimed" value={p.total_unclaimed} icon={Circle} tone="warning" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
