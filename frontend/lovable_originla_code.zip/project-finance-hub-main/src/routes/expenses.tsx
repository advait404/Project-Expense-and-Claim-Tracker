import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Plus, Pencil, Trash2, FileText, PencilLine } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { LoadingState, ErrorState, EmptyState } from "@/components/States";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  getExpenses,
  createExpense,
  updateExpense,
  deleteExpense,
  toggleExpenseClaim,
  type ExpenseFilters,
} from "@/api/expenses";
import { useProjects } from "@/hooks/useProjects";
import { EXPENSE_CATEGORIES } from "@/types";
import type { Expense } from "@/types";
import { formatMYR, formatDate } from "@/lib/format";

export const Route = createFileRoute("/expenses")({
  component: ExpensesPage,
});

const ALL = "__all__";

function ExpensesPage() {
  const { data: projects } = useProjects();
  const [filters, setFilters] = useState<ExpenseFilters>({});
  const [data, setData] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Expense | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await getExpenses(filters));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load expenses");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(filters)]);

  const projectName = useMemo(() => {
    const m = new Map(projects.map((p) => [p.id, p.name]));
    return (id: string) => m.get(id) ?? id;
  }, [projects]);

  const handleToggle = async (exp: Expense) => {
    // Optimistic update
    setData((prev) =>
      prev.map((e) => (e.id === exp.id ? { ...e, is_claimed: !e.is_claimed } : e)),
    );
    try {
      await toggleExpenseClaim(exp.id);
    } catch (err) {
      // revert
      setData((prev) =>
        prev.map((e) => (e.id === exp.id ? { ...e, is_claimed: exp.is_claimed } : e)),
      );
      toast.error(err instanceof Error ? err.message : "Toggle failed");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this expense?")) return;
    try {
      await deleteExpense(id);
      toast.success("Deleted");
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete failed");
    }
  };

  return (
    <div>
      <PageHeader
        title="Expenses"
        description="All expenses across projects. Toggle claimed status inline."
        actions={
          <Button
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus className="h-4 w-4" /> New Expense
          </Button>
        }
      />

      {/* Filters */}
      <div className="grid gap-3 mb-4 md:grid-cols-5">
        <div>
          <Label className="text-xs">Project</Label>
          <Select
            value={filters.project_id ?? ALL}
            onValueChange={(v) =>
              setFilters((f) => ({ ...f, project_id: v === ALL ? undefined : v }))
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="All" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>All projects</SelectItem>
              {projects.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">Category</Label>
          <Select
            value={filters.category ?? ALL}
            onValueChange={(v) =>
              setFilters((f) => ({ ...f, category: v === ALL ? undefined : v }))
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="All" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>All categories</SelectItem>
              {EXPENSE_CATEGORIES.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">From</Label>
          <Input
            type="date"
            value={filters.date_from ?? ""}
            onChange={(e) =>
              setFilters((f) => ({ ...f, date_from: e.target.value || undefined }))
            }
          />
        </div>
        <div>
          <Label className="text-xs">To</Label>
          <Input
            type="date"
            value={filters.date_to ?? ""}
            onChange={(e) =>
              setFilters((f) => ({ ...f, date_to: e.target.value || undefined }))
            }
          />
        </div>
        <div>
          <Label className="text-xs">Claim Status</Label>
          <Select
            value={
              filters.is_claimed === undefined ? ALL : filters.is_claimed ? "yes" : "no"
            }
            onValueChange={(v) =>
              setFilters((f) => ({
                ...f,
                is_claimed: v === ALL ? undefined : v === "yes",
              }))
            }
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>All</SelectItem>
              <SelectItem value="yes">Claimed</SelectItem>
              <SelectItem value="no">Unclaimed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {loading && <LoadingState />}
      {error && <ErrorState message={error} onRetry={load} />}
      {!loading && !error && data.length === 0 && (
        <EmptyState title="No expenses found" description="Try changing filters or add a new expense." />
      )}

      {!loading && !error && data.length > 0 && (
        <div className="rounded-md border bg-card overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Project</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Vendor / Description</TableHead>
                <TableHead>Category</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead>Source</TableHead>
                <TableHead>Claimed</TableHead>
                <TableHead>Claimed Date</TableHead>
                <TableHead className="w-24" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((exp) => {
                const negative = exp.amount < 0;
                return (
                  <TableRow key={exp.id}>
                    <TableCell className="text-sm">
                      {exp.project_name ?? projectName(exp.project_id)}
                    </TableCell>
                    <TableCell className="text-sm">{formatDate(exp.date)}</TableCell>
                    <TableCell>
                      <div className="font-medium">{exp.vendor}</div>
                      {exp.description && (
                        <div className="text-xs text-muted-foreground line-clamp-1">
                          {exp.description}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{exp.category}</Badge>
                    </TableCell>
                    <TableCell
                      className={`text-right font-mono ${negative ? "text-destructive" : ""}`}
                    >
                      {formatMYR(exp.amount)}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="gap-1">
                        {exp.source === "pdf" ? (
                          <FileText className="h-3 w-3" />
                        ) : (
                          <PencilLine className="h-3 w-3" />
                        )}
                        {exp.source}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={exp.is_claimed}
                          onCheckedChange={() => handleToggle(exp)}
                        />
                        {exp.is_claimed ? (
                          <Badge className="bg-success text-success-foreground hover:bg-success/90">
                            Claimed
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="border-warning text-warning">
                            Unclaimed
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {formatDate(exp.claimed_date)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => {
                            setEditing(exp);
                            setOpen(true);
                          }}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleDelete(exp.id)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      <ExpenseDialog
        open={open}
        onOpenChange={setOpen}
        expense={editing}
        onSaved={() => {
          setOpen(false);
          load();
        }}
      />
    </div>
  );
}

function ExpenseDialog({
  open,
  onOpenChange,
  expense,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  expense: Expense | null;
  onSaved: () => void;
}) {
  const { data: projects } = useProjects();
  const [form, setForm] = useState<Partial<Expense>>({
    project_id: "",
    date: new Date().toISOString().slice(0, 10),
    vendor: "",
    description: "",
    amount: 0,
    currency: "MYR",
    category: "Other",
    is_claimed: false,
    notes: "",
    source: "manual",
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setForm(
        expense ?? {
          project_id: projects[0]?.id ?? "",
          date: new Date().toISOString().slice(0, 10),
          vendor: "",
          description: "",
          amount: 0,
          currency: "MYR",
          category: "Other",
          is_claimed: false,
          notes: "",
          source: "manual",
        },
      );
    }
  }, [open, expense, projects]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (expense) {
        await updateExpense(expense.id, form);
        toast.success("Expense updated");
      } else {
        await createExpense({ ...form, source: "manual" });
        toast.success("Expense created");
      }
      onSaved();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{expense ? "Edit Expense" : "New Expense"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Project</Label>
              <Select
                value={form.project_id}
                onValueChange={(v) => setForm({ ...form, project_id: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select project" />
                </SelectTrigger>
                <SelectContent>
                  {projects.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Date</Label>
              <Input
                type="date"
                required
                value={form.date ?? ""}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
              />
            </div>
          </div>
          <div>
            <Label>Vendor</Label>
            <Input
              required
              value={form.vendor ?? ""}
              onChange={(e) => setForm({ ...form, vendor: e.target.value })}
            />
          </div>
          <div>
            <Label>Description</Label>
            <Input
              value={form.description ?? ""}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label>Amount</Label>
              <Input
                type="number"
                step="0.01"
                required
                value={form.amount ?? 0}
                onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })}
              />
            </div>
            <div>
              <Label>Currency</Label>
              <Input
                value={form.currency ?? "MYR"}
                onChange={(e) => setForm({ ...form, currency: e.target.value })}
              />
            </div>
            <div>
              <Label>Category</Label>
              <Select
                value={form.category}
                onValueChange={(v) => setForm({ ...form, category: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {EXPENSE_CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Switch
              checked={form.is_claimed ?? false}
              onCheckedChange={(v) => setForm({ ...form, is_claimed: v })}
              id="claimed"
            />
            <Label htmlFor="claimed">Marked as claimed</Label>
          </div>
          <div>
            <Label>Notes</Label>
            <Textarea
              value={form.notes ?? ""}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving || !form.project_id}>
              {saving ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
