// Base API client. Change BASE_URL to point at your FastAPI backend.
const BASE_URL = "http://localhost:8000/api";

export async function apiRequest<T>(
  endpoint: string,
  method: string = "GET",
  body?: unknown,
): Promise<T> {
  const res = await fetch(`${BASE_URL}${endpoint}`, {
    method,
    headers: {
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({}) as { message?: string });
    throw new Error((error as { message?: string }).message || "API Error");
  }

  return res.json() as Promise<T>;
}

// Multipart variant for PDF upload
export async function apiUpload<T>(endpoint: string, formData: FormData): Promise<T> {
  const res = await fetch(`${BASE_URL}${endpoint}`, {
    method: "POST",
    body: formData,
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({}) as { message?: string });
    throw new Error((error as { message?: string }).message || "Upload failed");
  }
  return res.json() as Promise<T>;
}
