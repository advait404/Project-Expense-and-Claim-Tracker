import { apiRequest, apiUpload } from "./client";
import type { Expense, ParsedTransaction, PdfUploadResponse } from "@/types";

// TODO: connect to backend endpoint: POST /api/pdf/upload
export const uploadPdf = (file: File) => {
  const fd = new FormData();
  fd.append("file", file);
  return apiUpload<PdfUploadResponse>("/pdf/upload", fd);
};

// TODO: connect to backend endpoint: POST /api/pdf/confirm
export const confirmPdfImport = (
  upload_id: string,
  project_id: string,
  transactions: ParsedTransaction[],
) =>
  apiRequest<Expense[]>("/pdf/confirm", "POST", {
    upload_id,
    project_id,
    transactions,
  });
